---
title: Hello, world.
date: Last Modified 
permalink: /
eleventyNavigation:
  key: Hello 
  order: 0
  title: Hello, world.
---
You have successfully launched your spacebook. If you are new here, you may want to [read the docs](https://spacebook.app/) for tips and tricks on setting up your project.

![Hello, world](/content/images/hello.jpg)

->*Onward...*<-



