---
layout: layouts/contact.njk
title: Send a message 
section: contact
date: Last Modified
permalink: /contact/index.html
---
You can use [Netlify Forms](https://www.netlify.com/docs/form-handling/) to create contact forms like this one, or any other custom forms you may wish to create. All submissions are sent directly to your Netlify dashboard (with optional notifications.) All forms utilize Netlify's native spam filter will display a CAPTCHA for any flagged submissions.
