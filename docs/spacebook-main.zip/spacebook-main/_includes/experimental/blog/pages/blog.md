---
layout: layouts/blog.njk
title: Spacelog 
date: 2020-12-21
permalink: /blog/index.html
eleventyNavigation:
  key: Spacelog
  order: 200
---